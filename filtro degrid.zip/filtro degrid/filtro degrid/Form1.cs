﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace filtro_degrid
{
    public partial class Form1 : Form
    {
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        DataTable dtSales = new DataTable();
        string filterField = "País";
        public Form1()
        {
           

            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //inicializar colunas
   dtSales.Columns.Add("País", typeof(string));
   dtSales.Columns.Add("Habitantes", typeof(int));
            //inserriri dados
   dtSales.Rows.Add(new object[] { "Angola", 2000 });
   dtSales.Rows.Add(new object[] { "Belgium", 4500 });
   

   dataGridView1.DataSource = dtSales;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            dtSales.DefaultView.RowFilter = string.Format("[{0}] LIKE '%{1}%'", filterField, textBoxFilter .Text );
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
